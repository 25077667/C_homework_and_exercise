This is a merge sort example in C's linkded list
===

Will compile to MIPS/x86_64 instruction to trace & demo.

# REF.
https://godbolt.org/
